import os
import pandas as pd
from tabulate import tabulate
import csv

from models.Converter import convert

class HojaDeVida():
    def __init__(self): 
        self._file = "../data/HDV.csv"

    def create(self):
        return convert()

    def read(self):
        direct = os.path.dirname(__file__)
        datos = os.path.join(direct,self._file) # Path completo de los datos
        dataset = pd.read_csv(datos) # Leer los datos con Panda
        matriz=[]
        with open('HV_BENEHEART_D6.csv') as File:
            reader = csv.reader(File, delimiter=';',skipinitialspace=True,
                                quoting=csv.QUOTE_MINIMAL)
            print(reader)
            for row in reader:
                row2=[item for item in row if len(item)>0]
                # print(row2)
                if len(row2)>0 :
                    matriz.append(row2)

        for i in range(len(matriz)):
            one=matriz[i]
            for j in range(len(one)):
                if one[j]=='x':
                    print(matriz[i][j-1])   
        
        return matriz        
