import os

class Equipo():
    _file = r"data/dispositivos.csv"
    def __init__(self,name,code,rs,brand,model,tipo,series,numAct):
        self.name = name
        self.code = code
        self.rs = rs
        self.brand = brand
        self.model = model
        self.tipo = tipo
        self.series = series
        self.numAct = numAct
    
    def create(self):
        directory = os.path.dirname(__file__)
        filePath = os.path.join(directory,self._file)
        print(filePath)
        file = open(filePath,"a")
        disp = file.readlines()
        file.close()
        if len(disp) == 0:
            datos = "Nombre" +";"+ "Código" +";"+ "Registro Sanitario" +";"+ "Marca" +";"+ "Modelo" +";"+ "Tipo" +";"+ "Serial" +";"+ "Número de Activo" +"\n"
        else:
            datos = self.name +";"+ self.code +";"+ self.rs +";"+ self.brand +";"+ self.model +";"+ self.tipo +";"+ self.series +";"+ self.numAct +"\n"
        file.write(datos)
        file.close()
    
    def selDisp(self,disp,num):
        for i in disp:
            dispositivo = i.split(";")
            print(dispositivo)
            if dispositivo[7] == num+"\n":
                indx = disp.index(i)
        d = disp[indx].split(";")
        return d,indx
    
    def edit(self,num):
        directory = os.path.dirname(__file__)
        filePath = os.path.join(directory,self._file)
        file = open(filePath,"r")
        disp = file.readlines()
        indx = 0
        print(disp)
        d,indx = self.selDisp(disp,num)
        print("¿Qué parámetro desea modificar?")
        print("[N]ombre")
        print("[C]ódigo")
        print("[R]egistro Sanitario")
        print("[M]arca")
        print("m[O]delo")
        print("[T]ipo")
        print("[S]erial")
        print("Número de [A]ctivo")
        opt = input(">>")
        if opt == "n":
            n_name = input("Ingrese el nueva nombre >>")
            d[0] = n_name
        elif opt == "c":
            n_code = input("Ingrese el nuevo código >>")
            d[1] = n_code
        elif opt == "r":
            n_rs = input("Ingrese el nuevo registro sanitario >>")
            d[2] = n_rs
        elif opt == "m":
            n_brand = input("Ingrese el nuevo marca >>")
            d[3] = n_brand
        elif opt == "o":
            n_model = input("Ingrese el nuevo modelo >>")
            d[4] = n_model
        elif opt == "t":
            n_tipo = input("Ingrese el nuevo tipo >>")
            d[5] = n_tipo
        elif opt == "s":
            n_series = input("Ingrese el nuevo tipo >>")
            d[6] = n_series
        elif opt == "a":
            n_activo = input("Ingrese el nuevo número de activo >>")
            d[7] = n_activo+"\n"     

        d_edit = [d[0],d[1],d[2],d[3],d[4],d[5],d[6],d[7]]
        d_edit = ";".join(d_edit)
        disp[indx] = d_edit
        disp = " ".join(disp)
        file.close()
        f = open(filePath, "w")
        f.write(disp)
        f.close()

    def erase(self,num):
        directory = os.path.dirname(__file__)
        filePath = os.path.join(directory,self._file)
        file = open(filePath,"r")
        disp = file.readlines()
        print(disp)
        d,indx = self.selDisp(disp,num)
        disp.remove(disp[indx])
        disp = "".join(disp)
        file.close()
        f = open(filePath, "w")
        f.write(disp)
        f.close()




